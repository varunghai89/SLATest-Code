'''
# ------------------------------------------------------------------------------------------------------------------------
# Token
# ------------------------------------------------------------------------------------------------------------------------
'''
import requests
import json
import Properties

############################################
HOSTNAME = Properties.Properties.HOSTNAME
TENANT = Properties.Properties.TENANT
USERNAME = Properties.Properties.USERNAME
PASSWORD = Properties.Properties.PASSWORD
API_TOKEN = Properties.Properties.API_TOKEN
############################################


def GetToken(API_TOKEN):
    try:
        URL = HOSTNAME+"/concerto/services/rest/RepositoryService/v1/Tokens"
        fp = requests.put(URL, data='{"apiToken":"'+API_TOKEN+'"}')
        js = json.loads(fp.content)
        if fp.status_code!=200:
            return str("Error: "+str(fp.status_code)+", "+fp.reason+", "+fp.content)
        token= js['token']
        return token
    except Exception as e:
        print("Failed to get Token "+str(e.args)+", "+str(e))

def UpdateTenantToken(USERNAME, PASSWORD, TENANT):
    try:
        URL = HOSTNAME+"/concerto/services/rest/RepositoryService/v1/Tokens"
        fp = requests.put(URL, data='{"userName":"'+USERNAME+'", "password":"'+PASSWORD+'", "tenant":"'+TENANT+'"}')
        js = json.loads(fp.content)
        token=js['token']
        print('::::::::::::::Getting Tenant Token::::::::::::::\n'+'INFO: Tenant Auth Token = '+token)
        return token
    except Exception as e:
        print("Failed to get Token "+str(e.args)+", "+str(e))
        quit()
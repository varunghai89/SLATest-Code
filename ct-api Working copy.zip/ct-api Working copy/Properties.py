'''
# ------------------------------------------------------------------------------------------------------------------------
# Define Properties Here
# ------------------------------------------------------------------------------------------------------------------------
'''
class Properties:
    ENV_NAME = 'SLATest Environment'
    CTM_TENANT = 'n/a'
    HOSTNAME = 'http://172.232.102.173'
    TENANT = 'CloudTest'
    COMPS_PATH = '/SLA Test/Compositions/1 Iteration Test'
    GRID_NAME = '5 Linode Locations'
    API_TOKEN = 'a363c666-e155-4d8a-a910-67dd6e1e1efd'
    USERNAME = 'vghai@akamai.com'
    PASSWORD = 'Akamai@123'
    LOGPATH = "./API.log"